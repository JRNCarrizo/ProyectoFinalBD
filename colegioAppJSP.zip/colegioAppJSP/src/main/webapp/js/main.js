function confirmarEliminacion() {
    return window.confirm("¿Estás seguro de que deseas eliminar?")
}