use colegio;

DROP TABLE IF EXISTS control_auditoria;
CREATE TABLE control_auditoria(
       id int AUTO_INCREMENT PRIMARY KEY,
    tabla varchar(50) not null,
    evento ENUM ('INSERT','UPDATE','DELETE') NOT NULL,
    id_registro INT,
    fecha date,
    hora time,
    usuario VARCHAR(50)   
);
-- ------------------------------------------------------------
-- ---Trigger (insert,update,delete) cursos--------------------
DROP TRIGGER IF EXISTS TR_cursos_insert;
CREATE TRIGGER TR_cursos_insert
AFTER INSERT ON cursos FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario)
            VALUES
            ('cursos','INSERT', NEW.id, CURDATE(), CURTIME(),
                USER());
    END; 

INSERT INTO cursos(titulo,profesor,dia,turno)VALUES
('Matematica','Roberto','MARTES','MAÑANA'),
('Programación','Carlos','LUNES','NOCHE'),
('C.Sociales','Ricardo','MIERCOLES','TARDE'),
('Lenguaje','Adrian','JUEVES','MAÑANA'),
('Programación','Juan','VIERNES','NOCHE');


  
select * from cursos;
select * from control_auditoria;  

-- --------------------------------------------------------------
DROP TRIGGER IF EXISTS TR_cursos_update;
CREATE TRIGGER TR_cursos_update
AFTER UPDATE ON cursos FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario)
            VALUES
            ('cursos','UPDATE', OLD.id, CURDATE(), CURTIME(),
                USER());
    END; 

update cursos set profesor='Jose' where id=1;
SELECT * from control_auditoria;

-- --------------------------------------------------------------
DROP TRIGGER IF EXISTS TR_cursos_delete;
CREATE TRIGGER TR_cursos_delete
AFTER DELETE ON cursos FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario)
            VALUES
            ('cursos','DELETE', OLD.id, CURDATE(), CURTIME(),
                USER());
    END; 

delete from cursos where id=2;
select * from control_auditoria;

-- --------------------------------------------------------------
-- ---Trigger (insert,update,delete) alumnos---------------------
DROP TRIGGER IF EXISTS TR_alumnos_insert;
CREATE TRIGGER TR_alumnos_insert
AFTER INSERT ON alumnos FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario)
            VALUES
            ('alumnos','INSERT', NEW.id, CURDATE(), CURTIME(),
                USER());
    END; 

INSERT INTO alumnos(nombre,apellido,edad,id_curso)VALUES
('Daniel','Páez',24,1),
('Raul','Perez',20,4),
('Maximo','Simone',30,3),
('Diego','Rodriguez',34,4),
('Alfredo','Bravo',40,4);

  
select * from alumnos;
select * from control_auditoria;  

-- --------------------------------------------------------------
DROP TRIGGER IF EXISTS TR_alumnos_update;
CREATE TRIGGER TR_alumnos_update
AFTER UPDATE ON alumnos FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario)
            VALUES
            ('alumnos','UPDATE', OLD.id, CURDATE(), CURTIME(),
                USER());
    END; 

update alumnos set nombre='Lorena' where id=1;
SELECT * from control_auditoria;

-- --------------------------------------------------------------
DROP TRIGGER IF EXISTS TR_alumnos_delete;
CREATE TRIGGER TR_alumnos_delete
AFTER DELETE ON alumnos FOR EACH ROW
    BEGIN
        INSERT INTO control_auditoria 
            (tabla, evento, id_registro, fecha, hora, usuario)
            VALUES
            ('alumnos','DELETE', OLD.id, CURDATE(), CURTIME(),
                USER());
    END; 

delete from alumnos where id=2;
select * from control_auditoria;
-- ---------------------------------------------------------------
-- Tabla alternativa REGISTROS ELIMINADOS (cursos)----------------

CREATE TABLE cursos_eliminados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_registro int,
    titulo VARCHAR(25),
    profesor VARCHAR(25),
    dia VARCHAR(25),
    turno VARCHAR(25)
);

-- --------------------------------------------------------------
DROP TRIGGER IF EXISTS TR_cursos_delete_alternativo;
CREATE TRIGGER TR_cursos_delete_alternativo
BEFORE DELETE ON cursos
FOR EACH ROW
BEGIN
    INSERT INTO cursos_eliminados (id_registro, titulo, profesor, dia, turno)
    VALUES 
    (OLD.id, OLD.titulo, OLD.profesor, OLD.dia, OLD.turno);
END;

delete from cursos where id=5;
SELECT * FROM cursos_eliminados;
----------------------------------------------------------------
-- Tabla alternativa REGISTROS ELIMINADOS (alumnos)-------------
CREATE TABLE alumnos_eliminados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_registro int,
    nombre VARCHAR(25),
    apellido VARCHAR(25),
    edad INT,
    id_curso INT
);

-- -------------------------------------------------------------
DROP TRIGGER IF EXISTS TR_alumnos_delete_alternativo;
CREATE TRIGGER TR_alumnos_delete_alternativo
BEFORE DELETE ON alumnos
FOR EACH ROW
BEGIN
    INSERT INTO alumnos_eliminados (id_registro, nombre, apellido, edad, id_curso)
    VALUES 
    (OLD.id, OLD.nombre, OLD.apellido, OLD.edad, OLD.id_curso);
END;

delete from alumnos where id=4;
SELECT * FROM alumnos_eliminados;